﻿using Lol.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;
using System.Text.Json;

namespace Lol.Controllers
{
    [Route("api/Champions")]
    [ApiController]
    public class ChampionController : ControllerBase
    {
        private static List<Champion> _champions = new List<Champion>();
        private static List<User> _users = new List<User>();
        private static int _nextId = 1;

        private const string FilePath = "champions.json";

        public ChampionController()
        {
            if (_champions.Count == 0 && System.IO.File.Exists(FilePath))
            {
                var json = System.IO.File.ReadAllText(FilePath);
                _champions = JsonSerializer.Deserialize<List<Champion>>(json) ?? new List<Champion>();

                if (_champions.Any())
                {
                    _nextId = _champions.Max(c => c.id) + 1;
                }
            }
        }

        private async Task SaveDataAsync()
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            var json = JsonSerializer.Serialize(_champions, options);
            await System.IO.File.WriteAllTextAsync(FilePath, json);
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] User user)
        {
            if (user == null || string.IsNullOrWhiteSpace(user.Username) || string.IsNullOrWhiteSpace(user.Password))
            {
                return await Task.FromResult(BadRequest("Érvénytelen felhasználói adatok!"));
            }

            if (_users.Any(u => u.Username == user.Username))
            {
                return await Task.FromResult(Conflict("Ez a felhasználónév már foglalt!"));
            }

            _users.Add(user);
            return await Task.FromResult(Ok(new { message = $"Sikeres regisztráció: {user.Username}" }));
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] User user)
        {
            var existingUser = _users.FirstOrDefault(u => u.Username == user.Username && u.Password == user.Password);

            if (existingUser == null)
            {
                return await Task.FromResult(Unauthorized("Hibás felhasználónév vagy jelszó!"));
            }

            return await Task.FromResult(Ok(new { message = "Sikeres bejelentkezés!" }));
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return await Task.FromResult(Ok(_champions));
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Champion champion)
        {
            if (champion == null)
            {
                return await Task.FromResult(BadRequest("Üres adatot küldtél!"));
            }

            champion.id = _nextId++;
            _champions.Add(champion);

            await SaveDataAsync();

            return await Task.FromResult(Ok(champion));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var champ = _champions.FirstOrDefault(c => c.id == id);

            if (champ == null)
            {
                return await Task.FromResult(NotFound("Nincs ilyen champion!"));
            }

            return await Task.FromResult(Ok(champ));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var champ = _champions.FirstOrDefault(c => c.id == id);

            if (champ == null)
            {
                return await Task.FromResult(NotFound("Nincs ilyen champion!"));
            }

            _champions.Remove(champ);

            await SaveDataAsync();

            return await Task.FromResult(Ok(new { message = "Sikeres törlés!" }));
        }
    }
}