﻿namespace Lol.Models
{
    public class Champion
    {
        public string name { get; set; }
        public string role { get; set; }
        public string lane { get; set; }
        public int difficulty { get; set; }
        public int blue_essence { get; set; }
        public string damage_type { get; set; }
        public string[] images { get; set; }
        public string description { get; set; }
        public int id { get; set; }

    }
}
