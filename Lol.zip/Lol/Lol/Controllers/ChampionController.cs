﻿using Lol.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;

namespace Lol.Controllers
{
    [Route("api/Champions")]
    [ApiController]
    public class ChampionController : ControllerBase
    {
        private static readonly List<Champion> _champions = new List<Champion>();
        private static int _nextId = 1;

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return await Task.FromResult(Ok(_champions));
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Champion champion)
        {
            if (champion == null)
                return await Task.FromResult(BadRequest("Empty body!"));

            champion.id = _nextId++;
            _champions.Add(champion);

            return await Task.FromResult(Ok(champion));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var champ = _champions.FirstOrDefault(c => c.id == id);

            if (champ == null)
                return await Task.FromResult(NotFound("Nincs ilyen champion!"));

            return await Task.FromResult(Ok(champ));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var champ = _champions.FirstOrDefault(c => c.id == id);

            if (champ == null)
                return await Task.FromResult(NotFound("Nincs ilyen champion!"));

            _champions.Remove(champ);

            return await Task.FromResult(Ok("Delete accomplished!"));
        }
    }
}